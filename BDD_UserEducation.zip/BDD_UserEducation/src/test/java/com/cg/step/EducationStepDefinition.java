package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {
	private WebDriver driver;
	private Education education;

	@Before
	public void init() {
		// instantiating driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		// driver = new ChromeDriver();
	}

	// @After
	// public void destroy() throws InterruptedException {
	// driver.quit();
	// }

	@Given("^User is on 'EducationalDetails' page$")
	public void user_is_on_EducationalDetails_page() throws Throwable {
		driver = new ChromeDriver();
		String url = "file:///C:/Users/dsanase/workspace3/BDD_UserEducation/html/EductionalDetails.html";
		driver.get(url);
		education = new Education();
		PageFactory.initElements(driver, education);

	}

	@Then("^validate educational details page$")
	public void validate_educational_details_page() throws Throwable {
		String title= driver.getTitle();
		if(title.equals("Educational Form")) {
			System.out.println("You are on Educational Details page");
		}
		else
		{
			System.out.println("This is wrong page");
		}
		driver.close();
	}

	@When("^User does not select Graduation$")
	public void user_does_not_select_Graduation() throws Throwable {
		education.selectGraduation(0);
	}

	@Then("^display 'Please Select Graduation'$")
	public void display_Please_Select_Graduation() throws Throwable {
		education.clickPaymentButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not select Percentage$")
	public void user_does_not_select_Percentage() throws Throwable {
		education.selectGraduation(1);
	}

	@Then("^display 'Please fill the percentage details'$")
	public void display_Please_fill_the_percentage_details() throws Throwable {
		education.clickPaymentButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter passing Year$")
	public void user_does_not_enter_passing_Year() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("85");
	}

	@Then("^display 'Please fill the passing year'$")
	public void display_Please_fill_the_passing_year() throws Throwable {
		education.clickPaymentButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter Project Name$")
	public void user_does_not_enter_Project_Name() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("85");
		education.setPassingYear("2018");
	}

	@Then("^display 'Please fill Project name'$")
	public void display_Please_fill_Project_name() throws Throwable {
		education.clickPaymentButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not select technologies$")
	public void user_does_not_select_technologies() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("85");
		education.setPassingYear("2018");
		education.setProjectName("Educational Web page");
	}

	@Then("^display 'Please select technology'$")
	public void display_Please_select_technology() throws Throwable {
		education.clickPaymentButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not select other Technology$")
	public void user_does_not_select_other_Technology() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("85");
		education.setPassingYear("2018");
		education.setProjectName("Educational Web page");
		education.selectTechnology(6);
	}

	@Then("^display 'Please fill other technology'$")
	public void display_Please_fill_other_technology() throws Throwable {
		education.clickPaymentButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters all valid Educational details$")
	public void user_enters_all_valid_Educational_details() throws Throwable {
		education.selectGraduation(1);
		education.setPercentage("85");
		education.setPassingYear("2018");
		education.setProjectName("Educational Web page");
		education.selectTechnology(6);
		education.setOtherTechno("Spring");

	}

	@Then("^display successful registration message$")
	public void display_successful_registration_message() throws Throwable {
		education.clickPaymentButton();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

}
