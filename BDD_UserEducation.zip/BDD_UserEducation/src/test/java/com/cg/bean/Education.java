package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {

	@FindBy(id = "Graduation")
	private WebElement Graduation;

	@FindBy(id = "Percentage")
	private WebElement Percentage;

	@FindBy(id = "passingYear")
	private WebElement passingYear;

	@FindBy(id = "ProjectName")
	private WebElement ProjectName;

	@FindBy(id = "technologies")
	private WebElement technologies;

	@FindBy(id = "otherTech")
	private WebElement otherTechno;

	@FindBy(id = "btnPayment")
	private WebElement btnPayment;

	// getter setter
	public String getGraduation() {
		return Graduation.getAttribute("value");
	}

	public void setGraduation(String graduation) {
		this.Graduation.sendKeys(graduation);
	}

	public String getPercentage() {
		return Percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.Percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return ProjectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.ProjectName.sendKeys(projectName);
	}

	public String getTechnologies() {
		return technologies.getAttribute("value");
	}

	public void setTechnologies(String technologies) {
		this.technologies.sendKeys(technologies);
	}

	public String getOtherTechno() {
		return otherTechno.getAttribute("value");
	}

	public void setOtherTechno(String otherTechno) {
		this.otherTechno.sendKeys(otherTechno);
	}

	public void clickPaymentButton() {
		btnPayment.click();
	}

	public void selectGraduation(int idx) {
		Select select = new Select(Graduation);
		select.selectByIndex(idx);
	}


	public void selectTechnology(int idx) {
		Select select = new Select(technologies);
		select.selectByIndex(idx);
	}

}
