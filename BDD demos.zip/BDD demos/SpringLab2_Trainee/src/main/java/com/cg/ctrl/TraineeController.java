package com.cg.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Login;
import com.cg.bean.Trainee;
import com.cg.service.ITraineeService;


@Controller
public class TraineeController {

	@Autowired
	ITraineeService service;

	//login 
	@RequestMapping("/")
	public String login(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "/checkLogin")
	public String checkLogin(Login login, Model model) {
		// Logic to validate userName and password
		if (login.getUserName().equalsIgnoreCase("dhanashri") && login.getPassword().equalsIgnoreCase("123")) {
			String loginSuccess = "Logged In Successfully!!!!";
			model.addAttribute("loginSuccess", loginSuccess);
			return "loginSuccess";
		} else {
			String invalid = "Invalid details, please enter valid details";
			model.addAttribute("invalid", invalid);
			return "login";
		}
	}

	
	//adding trainee record to database
	@RequestMapping(value = "/addTrainee")
	public String addTrainee(Model model, Trainee trainee) {
		model.addAttribute("trainee", new Trainee());
		return "addTrainee";
	}

	
	@RequestMapping(value = "/addDetails")
	public String addDetails(Model model, Trainee trainee) {
		service.addDetails(trainee);
		String addingSuccess = "Trainee added Successfully!!!!";
		model.addAttribute("addingSuccess", addingSuccess);
		return "loginSuccess";
	}
	
	
	//deleting trainee record
	@RequestMapping(value = "/deleteTrainee")
	public String deleteTrainee(Model model) {
		return "deleteTrainee";
	}

	
	@RequestMapping(value = "/search")
	public String retrieveDetails(Model model,@RequestParam("id") int id) {
		Trainee trainee = service.retrieveTrainee(id);
		model.addAttribute("trainee" , trainee);
		return "deleteTrainee";
	}
	
	
	@RequestMapping(value = "/deleteDetails")
	public String deleteDetails(Model model,@RequestParam("trainee") Trainee trainee) {
		service.deleteDetails(trainee);
		String deletingSuccess = "Trainee deleted Successfully!!!!";
		model.addAttribute("deletingSuccess", deletingSuccess);
		return "loginSuccess";
	}
	
	
	//retrieving record by id
	@RequestMapping(value = "/findTrainee")
	public String findTrainee(Model model) {
		return "findTrainee";
	}

	@RequestMapping(value = "/find")
	public String findDetails(Model model,@RequestParam("id") int id) {
		Trainee trainee = service.retrieveTrainee(id);
		model.addAttribute("trainee" , trainee);
		String foundTrainee = "Trainee deatils are as below :";
		model.addAttribute("foundTrainee", foundTrainee);
		return "findTrainee";
	}
	
	//go back logic
	@RequestMapping(value = "/goBack")
	public String goBack(Model model) {
		return "loginSuccess";
	}
	
	
	//retrieving all records
	@RequestMapping(value = "/retrieveAll")
	public String retrieveAll(Model model) {
		List<Trainee> trainees = service.retrieveAllTrainees();
		model.addAttribute("trainees" , trainees);
		return "retrieveAll";
	}
	
	
	
	//updating Trainee records
	@RequestMapping(value = "/updateTrainee")
	public String updateTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "updateTrainee";
	}
	
	@RequestMapping(value = "/searchToUpdate")
	public String searchToUpdate(Model model,@RequestParam("id") int id) {
		Trainee trainee = service.retrieveTrainee(id);
		model.addAttribute("trainee" , trainee);
		return "updateTrainee";
	}
	
	@RequestMapping(value = "/updateDetails")
	public String updateDetails(Model model, Trainee trainee) {
		service.modifyDetails(trainee);
		String modifySuccess = "Trainee record mogified Successfully!!!!";
		model.addAttribute("modifySuccess", modifySuccess);
		return "loginSuccess";
	}	
}
