/**
 * 
 */
package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.Trainee;

/**
 * @author Dhanshri Sanase
 *
 */
public interface TraineeRepo extends CrudRepository<Trainee, Integer> {

}
