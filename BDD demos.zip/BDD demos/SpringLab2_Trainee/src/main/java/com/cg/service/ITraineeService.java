package com.cg.service;

import java.util.List;

import com.cg.bean.Trainee;

public interface ITraineeService {

	public void addDetails(Trainee trainee);
	public void deleteDetails(Trainee trainee);
	public void modifyDetails(Trainee trainee);
	public Trainee retrieveTrainee(int id);
	public List<Trainee> retrieveAllTrainees();
}
