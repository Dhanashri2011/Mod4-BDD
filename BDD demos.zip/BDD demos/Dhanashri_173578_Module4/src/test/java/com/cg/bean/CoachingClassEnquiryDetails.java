package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

/**
 * Bean class of coaching class enquiry details
 * 
 * @author Dhanashri Sanase
 */
public class CoachingClassEnquiryDetails {

	// finding Web Elements by id
	@FindBy(id = "fname")
	private WebElement firstName;

	@FindBy(id = "lname")
	private WebElement lastName;

	@FindBy(id = "emails")
	private WebElement email;

	@FindBy(id = "mobile")
	private WebElement mobileNumber;

	@FindBy(name = "D6")
	private WebElement tutionRequired;

	@FindBy(name = "D5")
	private WebElement preferredCity;

	@FindBy(name = "D4")
	private WebElement learningMode;

	@FindBy(id = "enqdetails")
	private WebElement enquiryDetails;

	@FindBy(id = "Submit1")
	private WebElement submitRequestButton;

	// getters and setters
	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getMobileNumber() {
		return mobileNumber.getAttribute("value");
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber.sendKeys(mobileNumber);
	}

	public String getTutionRequired() {
		return tutionRequired.getAttribute("value");
	}

	public void setTutionRequired(String tutionRequired) {
		this.tutionRequired.sendKeys(tutionRequired);
	}

	public String getPreferredCity() {
		return preferredCity.getAttribute("value");
	}

	public void setPreferredCity(String preferredCity) {
		this.preferredCity.sendKeys(preferredCity);
	}

	public String getLearningMode() {
		return learningMode.getAttribute("value");
	}

	public void setLearningMode(String learningMode) {
		this.learningMode.sendKeys(learningMode);
	}

	public String getEnquiryDetails() {
		return enquiryDetails.getAttribute("value");
	}

	public void setEnquiryDetails(String enquiryDetails) {
		this.enquiryDetails.sendKeys(enquiryDetails);
	}

	// to click submit button method
	public void clickSubmit() {
		submitRequestButton.click();
	}

	// to select required tution
	public void selectTution(int idx) {
		Select select = new Select(tutionRequired);
		select.selectByIndex(idx);
	}

	// to select preferred city
	public void selectCity(int idx) {
		Select select = new Select(preferredCity);
		select.selectByIndex(idx);
	}

	// to select learning mode
	public void selectLearningMode(int idx) {
		Select select = new Select(learningMode);
		select.selectByIndex(idx);
	}

}
