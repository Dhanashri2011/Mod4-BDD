package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.CoachingClassEnquiryDetails;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Step definition class for coaching class enquiry form validations
 * 
 * @author Dhanashri Sanase
 */
public class CoachingClassEnquiryStepDefinition {

	private WebDriver driver;
	private CoachingClassEnquiryDetails enquiryDetails;

	@Before
	public void init() {
		// setting chrome driver property
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
	}

	@Given("^User is on 'Coaching_Class_enquiry' page$")
	public void user_is_on_Coaching_Class_enquiry_page() throws Throwable {
		driver = new ChromeDriver();
		String url = "file:///C:/Users/dsanase/workspace3/Dhanashri_173578_Module4/htmlFiles/Coaching_Class_Enquiry.html";
		driver.get(url);
		enquiryDetails = new CoachingClassEnquiryDetails();
		PageFactory.initElements(driver, enquiryDetails);
		Thread.sleep(2000);
	}

	/**
	 * verifying title of page
	 * 
	 * @throws Throwable
	 */
	@Then("^Validate title of Coaching class enquiry page$")
	public void validate_title_of_Coaching_class_enquiry_page() throws Throwable {
		String title = driver.getTitle();
		if (title.equals("Online Coaching Class Enquiry Form")) {
			System.out.println("You are on Online Coaching Class Enquiry page");
		} else {
			System.out.println("This is wrong page");
		}
		driver.close();
	}

	/**
	 * ensuring first name is filled out
	 * 
	 * @throws Throwable
	 */
	@When("^first name is not filled out$")
	public void first_name_is_not_filled_out() throws Throwable {
		enquiryDetails.setFirstName("");
	}

	@Then("^display 'First Name must be filled out'$")
	public void display_First_Name_must_be_filled_out() throws Throwable {
		enquiryDetails.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	/**
	 * ensuring last name is filled out
	 * 
	 * @throws Throwable
	 */
	@When("^last name is not filled out$")
	public void last_name_is_not_filled_out() throws Throwable {
		enquiryDetails.setFirstName("Dhanashri");
		enquiryDetails.setLastName("");
	}

	@Then("^display 'Last Name must be filled out'$")
	public void display_Last_Name_must_be_filled_out() throws Throwable {
		enquiryDetails.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	/**
	 * ensuring email is filled out
	 * 
	 * @throws Throwable
	 */
	@When("^email is not filled out$")
	public void email_is_not_filled_out() throws Throwable {
		enquiryDetails.setFirstName("Dhanashri");
		enquiryDetails.setLastName("Sanase");
		enquiryDetails.setEmail("");
	}

	@Then("^display 'Email must be filled out'$")
	public void display_Email_must_be_filled_out() throws Throwable {
		enquiryDetails.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	/**
	 * ensuring numeric mobile number is filled out
	 * 
	 * @throws Throwable
	 */
	@When("^numeric data is not entered in mobile text box$")
	public void numeric_data_is_not_entered_in_mobile_text_box() throws Throwable {

		enquiryDetails.setFirstName("Dhanashri");
		enquiryDetails.setLastName("Sanase");
		enquiryDetails.setEmail("dhanashri@gmail.com");
		enquiryDetails.setMobileNumber("abcd");
	}

	@Then("^display 'Enter numeric mobile number value\\.'$")
	public void display_Enter_numeric_mobile_number_value() throws Throwable {
		enquiryDetails.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	/**
	 * ensuring mobile number is a 10 digit number
	 * 
	 * @throws Throwable
	 */
	@When("^wrong data entered in mobile text box$")
	public void wrong_data_entered_in_mobile_text_box() throws Throwable {
		enquiryDetails.setFirstName("Dhanashri");
		enquiryDetails.setLastName("Sanase");
		enquiryDetails.setEmail("dhanashri@gmail.com");
		enquiryDetails.setMobileNumber("9987");
	}

	@Then("^display 'Enter (\\d+) digit mobile number\\.'$")
	public void display_Enter_digit_mobile_number(int arg1) throws Throwable {
		enquiryDetails.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	/**
	 * ensuring enquiry details are filled out
	 * 
	 * @throws Throwable
	 */
	@When("^insufficient enquiry details entered$")
	public void insufficient_enquiry_details_entered() throws Throwable {
		enquiryDetails.setFirstName("Dhanashri");
		enquiryDetails.setLastName("Sanase");
		enquiryDetails.setEmail("dhanashri@gmail.com");
		enquiryDetails.setMobileNumber("9876543210");
		enquiryDetails.selectTution(1);
		enquiryDetails.selectCity(1);
		enquiryDetails.selectLearningMode(1);
		enquiryDetails.setEnquiryDetails("");
	}

	@Then("^display 'Enquiry details muct be filled out\\.'$")
	public void display_Enquiry_details_muct_be_filled_out() throws Throwable {
		enquiryDetails.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	/**
	 * ensuring all details are filled out
	 * 
	 * @throws Throwable
	 */
	@When("^all enquiry details entered$")
	public void all_enquiry_details_entered() throws Throwable {
		enquiryDetails.setFirstName("Dhanashri");
		enquiryDetails.setLastName("Sanase");
		enquiryDetails.setEmail("dhanashri@gmail.com");
		enquiryDetails.setMobileNumber("9876543210");
		enquiryDetails.selectTution(1);
		enquiryDetails.selectCity(1);
		enquiryDetails.selectLearningMode(2);
		enquiryDetails.setEnquiryDetails("My all enquiry details.");

	}

	@Then("^display 'Thank you for submitting the online coaching Class Enquiry\\.\\.'$")
	public void display_Thank_you_for_submitting_the_online_coaching_Class_Enquiry() throws Throwable {
		enquiryDetails.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		if (driver.getPageSource().contains("Our Counselor will contact you soon.")) {
			System.out.println("Text exists");
			driver.close();
		} else {
			System.out.println("Text does not exist");
			driver.close();
		}
	}

}
