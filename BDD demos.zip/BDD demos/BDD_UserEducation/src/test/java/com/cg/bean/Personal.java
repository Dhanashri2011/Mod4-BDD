package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {
	

	@FindBy(id = "txtFirstName")
	private WebElement txtFirstName;
	
	@FindBy(id = "txtLastName")
	private WebElement txtLastName;
	
	@FindBy(id = "txtEmail")
	private WebElement txtEmail;
	
	@FindBy(id = "txtPhone")
	private WebElement txtPhone;
	
	@FindBy(id = "address1")
	private WebElement address1;
	
	@FindBy(id = "address2")
	private WebElement address2;
	
	@FindBy(id = "city")
	private WebElement city;
	
	@FindBy(id = "state")
	private WebElement state;
	
	@FindBy(id = "Next")
	private WebElement Next;

	
	//getters and setters
	public String getTxtFirstName() {
		return txtFirstName.getAttribute("value");
	}

	public void setTxtFirstName(String txtFirstName) {
		this.txtFirstName.sendKeys(txtFirstName);
	}
	
	public String getTxtLastName() {
		return txtLastName.getAttribute("value");
	}

	public void setTxtLastName(String txtLastName) {
		this.txtLastName.sendKeys(txtLastName);
	}
	public String getTxtEmail() {
		return txtEmail.getAttribute("value");
	}

	public void setTxtEmail(String txtEmail) {
		this.txtEmail.sendKeys(txtEmail);
	}
	public String getTxtPhone() {
		return txtPhone.getAttribute("value");
	}

	public void setTxtPhone(String txtPhone) {
		this.txtPhone.sendKeys(txtPhone);
	}
	public String getAddress1() {
		return address1.getAttribute("value");
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}
	public String getAddress2() {
		return address2.getAttribute("value");
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}
	public String getCity() {
		return city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	public String getState() {
		return state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}
	
	public void clickNext() {
		Next.click();
	}
	
	public void selectCity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}
	
	public void selectState(int idx) {
		Select select = new Select(state);
		select.selectByIndex(idx);
	}
}
