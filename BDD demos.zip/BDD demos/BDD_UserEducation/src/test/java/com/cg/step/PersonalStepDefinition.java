package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void init() {
		// instantiating driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
//		driver = new ChromeDriver();
	}
//	@After
//	public void destroy() throws InterruptedException {
//		driver.quit();
//	}

	@Given("^User is on 'PersonalDetails' page$")
	public void user_is_on_PersonalDetails_page() throws Throwable {
		driver = new ChromeDriver();
		String url = "file:///C://Users//dsanase//workspace3//BDD_UserEducation//html//PersonalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
	}

	@Then("^validate personal details page$")
	public void validate_personal_details_page() throws Throwable {
		String title= driver.getTitle();
		if(title.equals("Personal Details")) {
			System.out.println("You are on Personal Details page");
		}
		else
		{
			System.out.println("This is wrong page");
		}
		driver.close();
	}
	
	
	@When("^User enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		Thread.sleep(500);
	//	personal.setTxtFirstName("");
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		//personal.setTxtLastName("");
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter email$")
	public void user_does_not_enter_email() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		//personal.setTxtEmail("");
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("nxgvb");
	}

	@Then("^display 'Please enter valid Email Id\\.'$")
	public void display_Please_enter_valid_Email_Id() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter Contact no$")
	public void user_does_not_enter_Contact_no() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("dhanashri@gmail.com");
	//	personal.setTxtPhone("");
	}

	@Then("^display 'Please fill the Contact No\\.'$")
	public void display_Please_fill_the_Contact_No() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters invalid Contact no$")
	public void user_enters_invalid_Contact_no() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("dhanashri@gmail.com");
		personal.setTxtPhone("1239874563");
	}

	@Then("^display 'Please enter valid Contact no\\.'$")
	public void display_Please_enter_valid_Contact_no() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter address (\\d+)$")
	public void user_does_not_enter_address(int arg1) throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("dhanashri@gmail.com");
		personal.setTxtPhone("9874563210");
	//	personal.setAddress1("");
	}

	@Then("^display 'Please fill the address (\\d+)'$")
	public void display_Please_fill_the_address(int arg1) throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not enter secondaddress$")
	public void user_does_not_enter_secondaddress() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("dhanashri@gmail.com");
		personal.setTxtPhone("9874563210");
		personal.setAddress1("Mumbai");
	}

	@Then("^display 'Please fill the second address'$")
	public void display_Please_fill_the_second_address() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not select city$")
	public void user_does_not_select_city() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("dhanashri@gmail.com");
		personal.setTxtPhone("9874563210");
		personal.setAddress1("Mumbai");
		personal.setAddress2("Airoli");
	//	personal.selectCity(0);
	}

	@Then("^display 'Please select city'$")
	public void display_Please_select_city() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User does not select state$")
	public void user_does_not_select_state() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("dhanashri@gmail.com");
		personal.setTxtPhone("9874563210");
		personal.setAddress1("Mumbai");
		personal.setAddress2("Airoli");
		personal.selectCity(1);
	//	personal.selectState(0);
	}

	@Then("^display 'Please select state'$")
	public void display_Please_select_state() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
		Thread.sleep(500);
		personal.setTxtFirstName("Dhanashri");
		personal.setTxtLastName("Sanase");
		personal.setTxtEmail("dhanashri@gmail.com");
		personal.setTxtPhone("9874563210");
		personal.setAddress1("Mumbai");
		personal.setAddress2("Airoli");
		personal.selectCity(1);
		personal.selectState(1);
	}

	@Then("^display 'Personal details are validated\\.'$")
	public void display_Personal_details_are_validated() throws Throwable {
		personal.clickNext();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

}
