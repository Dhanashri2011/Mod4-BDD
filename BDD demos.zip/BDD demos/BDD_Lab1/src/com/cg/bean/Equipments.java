package com.cg.bean;

import java.util.Date;

import org.openqa.selenium.support.FindBy;

public class Equipments {
	
	@FindBy(id = "purchaseMethod")
	private String purchaseMethod ;
	
	@FindBy(id = "seqNumber")
	private int seqNumber;
	
	@FindBy(id = "userId")
	private int userId;
	
	@FindBy(id = "departmentId")
	private int departmentId;
	
	@FindBy(id = "useStatus")
	private String useStatus ;
	
	@FindBy(id = "costCenter")
	private String costCenter ;
	
	@FindBy(id = "installDate")
	private Date installDate ;
	
	@FindBy(id = "location")
	private String location ;
	
	@FindBy(id = "auditIndicator")
	private String auditIndicator  ;
	
	@FindBy(id = "auditDate")
	private Date auditDate ;
	
	@FindBy(id = "comments")
	private String comments ;
	
	@FindBy(id = "stockLocation")
	private String stockLocation ;
	
	
	
}
