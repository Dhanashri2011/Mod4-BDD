/**
 * 
 */
package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * @author Dhanashri Sanase
 * User bean
 */
public class User {

	
}
